# CSEE4119 hd2337 Hengming Dai java

	a. The function of my code is works almost same as the Programming+Assignment+1 described.
	b. The development environment for my code is ubuntu 14.10, Java version 1.6.0_36, Eclipse 3.8.1
	c.
	1. The way to run the code, frist we need unzip from the hd2337_java.zip.
	2. Then type make in terminal, the Client.class and the Server.class will occur automatic.
	3. Then you need server first, the way to invoke server will be " java Server", you can change the port number by changing the value of variable "serverPort". The default the port number is 5358.
	4. Then you need revoke client. The way to invoke client will be "java Client" , the default port number is 5358 which will match the server. You can change the port number by changing the value of variable "PORT".
	5. The mutiple client could be implement just run the "java Client" in different terminal.
	d.
	The way to use command is totally same as the Appendix:Example in programming+Assignment+1 description
	 
